/* Doondo website behaviour: language, Lite mode, the scroll clock, live counter,
   voice search, first match, hired feed and the Skill Passport builder. */
(function () {
  'use strict';

  var CFG = window.DOONDO_CONFIG || {};
  var STR = window.DOONDO_I18N, LANGS = window.DOONDO_LANGS, TRADES = window.DOONDO_TRADES;
  var City = window.DoondoCity;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var root = document.documentElement;
  var store = {
    get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) { /* storage blocked */ } }
  };

  // ── Places: pincode prefix → city, centre, areas ─────────────────────────
  var CITIES = [
    { pre: '560', pin: '560066', city: 'Bengaluru', lat: 12.97, lng: 77.59, areas: ['Whitefield', 'Koramangala', 'Jayanagar', 'Indiranagar', 'Yelahanka', 'HSR Layout'] },
    { pre: '110', pin: '110024', city: 'Delhi', lat: 28.61, lng: 77.21, areas: ['Lajpat Nagar', 'Dwarka', 'Karol Bagh', 'Rohini', 'Saket'] },
    { pre: '400', pin: '400053', city: 'Mumbai', lat: 19.08, lng: 72.88, areas: ['Andheri', 'Dadar', 'Thane', 'Borivali', 'Kurla'] },
    { pre: '600', pin: '600017', city: 'Chennai', lat: 13.08, lng: 80.27, areas: ['T. Nagar', 'Velachery', 'Anna Nagar', 'Tambaram', 'Adyar'] },
    { pre: '500', pin: '500032', city: 'Hyderabad', lat: 17.39, lng: 78.49, areas: ['Gachibowli', 'Ameerpet', 'Kukatpally', 'Secunderabad', 'Madhapur'] },
    { pre: '411', pin: '411057', city: 'Pune', lat: 18.52, lng: 73.86, areas: ['Hinjewadi', 'Kothrud', 'Hadapsar', 'Wakad'] },
    { pre: '700', pin: '700091', city: 'Kolkata', lat: 22.57, lng: 88.36, areas: ['Salt Lake', 'Howrah', 'Park Street', 'Behala'] },
    { pre: '380', pin: '380009', city: 'Ahmedabad', lat: 23.02, lng: 72.57, areas: ['Navrangpura', 'Maninagar', 'Satellite', 'Bopal'] },
    { pre: '302', pin: '302001', city: 'Jaipur', lat: 26.91, lng: 75.79, areas: ['Malviya Nagar', 'Vaishali Nagar', 'Mansarovar'] },
    { pre: '226', pin: '226010', city: 'Lucknow', lat: 26.85, lng: 80.95, areas: ['Gomti Nagar', 'Aliganj', 'Hazratganj'] },
    { pre: '641', pin: '641012', city: 'Coimbatore', lat: 11.02, lng: 76.96, areas: ['Gandhipuram', 'RS Puram', 'Peelamedu'] },
    { pre: '570', pin: '570009', city: 'Mysuru', lat: 12.30, lng: 76.64, areas: ['Kuvempunagar', 'Vijayanagar', 'Gokulam'] },
    { pre: '530', pin: '530017', city: 'Visakhapatnam', lat: 17.69, lng: 83.22, areas: ['MVP Colony', 'Gajuwaka', 'Dwaraka Nagar'] },
    { pre: '682', pin: '682024', city: 'Kochi', lat: 9.93, lng: 76.27, areas: ['Edappally', 'Kakkanad', 'Vyttila'] }
  ];
  function cityForPin(pin) {
    for (var i = 0; i < CITIES.length; i++) if (pin.indexOf(CITIES[i].pre) === 0) return CITIES[i];
    return null;
  }
  var place = { c: CITIES[0], area: 'Whitefield' };

  // ── i18n ─────────────────────────────────────────────────────────────────
  var lang = 'en';
  function t(key, vars) {
    var s = (STR[lang] && STR[lang][key]) || STR.en[key] || key;
    if (vars) Object.keys(vars).forEach(function (k) { s = s.split('{' + k + '}').join(vars[k]); });
    return s;
  }
  function tradeLabel(id) { var tr = tradeById(id); return tr ? (tr[lang] || tr.en) : id; }
  function tradeById(id) { for (var i = 0; i < TRADES.length; i++) if (TRADES[i].id === id) return TRADES[i]; return null; }
  var loadedFonts = {};
  function loadFont(l) {
    var f = LANGS[l] && LANGS[l].font;
    if (!f || loadedFonts[f]) return;
    loadedFonts[f] = 1;
    var link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = 'https://fonts.googleapis.com/css2?family=' + f + ':wght@400;500;600;700&display=swap';
    document.head.appendChild(link);
  }
  function applyLang(l) {
    lang = STR[l] ? l : 'en';
    root.lang = lang;
    store.set('doondo.lang', lang);
    loadFont(lang);
    $$('[data-i18n]').forEach(function (el) { el.textContent = t(el.getAttribute('data-i18n')); });
    $$('[data-i18n-ph]').forEach(function (el) { el.placeholder = t(el.getAttribute('data-i18n-ph')); });
    $('#langGlyph').textContent = LANGS[lang].glyph;
    $$('#langMenu button').forEach(function (b) { b.setAttribute('aria-current', b.dataset.lang === lang ? 'true' : 'false'); });
    fillTradeSelect($('#trade')); fillTradeSelect($('#ppTrade'));
    updateWaLinks(); renderCounter(); renderFeed(); renderJobs(); renderPassport(false); renderStarsLabel();
  }
  function fillTradeSelect(sel) {
    var v = sel.value || sel.dataset.v || 'electrician';
    sel.innerHTML = '';
    TRADES.forEach(function (tr) {
      var o = document.createElement('option'); o.value = tr.id; o.textContent = tr[lang] || tr.en; sel.appendChild(o);
    });
    sel.value = v;
  }

  // ── WhatsApp ─────────────────────────────────────────────────────────────
  function wa(text, toDoondo) {
    var num = toDoondo === false ? '' : (CFG.whatsappNumber || '');
    return 'https://wa.me/' + num + '?text=' + encodeURIComponent(text);
  }
  function updateWaLinks() {
    $$('[data-wa]').forEach(function (a) { a.href = wa(t('wa.' + a.dataset.wa)); });
    var app = $('#appLink'); if (app) app.href = CFG.playStoreUrl || '#';
  }

  // ── Toast ────────────────────────────────────────────────────────────────
  var toastTimer;
  function toast(msg, ms) {
    var el = $('#toast'); el.textContent = msg; el.hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { el.hidden = true; }, ms || 3200);
  }

  // ── Lite mode ────────────────────────────────────────────────────────────
  function isLite() { return root.classList.contains('lite'); }
  function setLite(on, announce) {
    root.classList.toggle('lite', on);
    $('#liteBtn').setAttribute('aria-pressed', on ? 'true' : 'false');
    if (on) City.pause(); else { City.resize(); City.start(); }
    updateHour(true);
    if (announce) toast(t(on ? 'nav.liteOn' : 'nav.liteOff'));
  }

  // ── Scroll clock: each section owns an hour ──────────────────────────────
  var anchors = [];
  function measure() {
    anchors = $$('[data-hour]').map(function (el) {
      var r = el.getBoundingClientRect();
      return { y: r.top + window.scrollY + r.height / 2, h: parseFloat(el.dataset.hour) };
    });
  }
  function hourNow() {
    var y = window.scrollY + window.innerHeight * 0.5;
    if (!anchors.length) return 5;
    if (y <= anchors[0].y) return anchors[0].h;
    for (var i = 0; i < anchors.length - 1; i++) {
      var a = anchors[i], b = anchors[i + 1];
      if (y <= b.y) return a.h + (b.h - a.h) * ((y - a.y) / (b.y - a.y));
    }
    return anchors[anchors.length - 1].h;
  }
  function fmtClock(h) {
    var mins = Math.round(h * 60 / 10) * 10, hh = Math.floor(mins / 60) % 24, mm = mins % 60;
    var ap = hh >= 12 ? 'PM' : 'AM', h12 = hh % 12 || 12;
    return h12 + ':' + (mm < 10 ? '0' : '') + mm + ' ' + ap;
  }
  var lastSkyKey = '';
  function updateHour(force) {
    var h = hourNow();
    var docH = document.documentElement.scrollHeight - window.innerHeight;
    City.setHour(h, docH > 0 ? window.scrollY / docH : 0);
    $('#clockTime').textContent = fmtClock(h) + ' · ' + place.c.city;
    $('#clockIco').classList.toggle('moon', h < 6 || h > 18.6);
    if (isLite()) {
      var key = (Math.round(h * 2) / 2).toFixed(1);
      if (force || key !== lastSkyKey) {
        lastSkyKey = key;
        var sk = City.skyAt(parseFloat(key)), c = function (v) { return 'rgb(' + (v[0] | 0) + ',' + (v[1] | 0) + ',' + (v[2] | 0) + ')'; };
        $('.lite-sky').style.setProperty('--sky', 'linear-gradient(180deg,' + c(sk[0]) + ',' + c(sk[1]) + ' 55%,' + c(sk[2]) + ')');
      }
    }
  }
  var ticking = false;
  window.addEventListener('scroll', function () {
    if (ticking) return; ticking = true;
    requestAnimationFrame(function () { ticking = false; updateHour(); });
  }, { passive: true });
  window.addEventListener('resize', function () { measure(); updateHour(true); });

  // ── Live "hired near you today" counter + feed ───────────────────────────
  var NAMES = ['Lakshmi R.', 'Imran S.', 'Priya K.', 'Suresh M.', 'Anita D.', 'Ravi T.', 'Fatima B.', 'Manoj P.', 'Kavya N.', 'Arjun V.', 'Deepa G.', 'Sanjay L.', 'Meena J.', 'Rahul C.', 'Selvi A.', 'Venkat R.', 'Pooja H.', 'Abdul K.'];
  var hiredCount = 0, feed = [];
  function seedCount() {
    var now = new Date(), mins = now.getHours() * 60 + now.getMinutes();
    var dayShare = Math.max(0.04, Math.min(1, (mins - 300) / 960)); // hiring runs ~5 AM to 9 PM
    hiredCount = Math.round(380 + 1650 * dayShare);
  }
  function renderCounter(bump) {
    var n = new Intl.NumberFormat('en-IN').format(hiredCount);
    $('#counterText').innerHTML = t('counter', { n: n, city: place.c.city });
    if (bump) { var b = $('#counterText b'); if (b) b.classList.add('bump'); }
  }
  function randomHire(minsAgo) {
    var tr = TRADES[Math.floor(Math.random() * TRADES.length)];
    return {
      name: NAMES[Math.floor(Math.random() * NAMES.length)],
      trade: tr.id,
      area: place.c.areas[Math.floor(Math.random() * place.c.areas.length)],
      at: Date.now() - minsAgo * 60000,
      isNew: false
    };
  }
  function seedFeed() { feed = [2, 5, 9, 14, 21].map(function (m) { return randomHire(m); }); }
  function renderFeed() {
    var ol = $('#feed'); ol.innerHTML = '';
    feed.forEach(function (f) {
      var li = document.createElement('li');
      if (f.isNew) li.className = 'new';
      var mins = Math.floor((Date.now() - f.at) / 60000);
      var initials = f.name.split(' ').map(function (p) { return p[0]; }).join('');
      li.innerHTML = '<span class="av">' + initials + '</span><span class="who"><b></b><span></span></span><time></time>';
      li.querySelector('b').textContent = f.name;
      li.querySelector('.who span').textContent = tradeLabel(f.trade) + ' · ' + f.area;
      li.querySelector('time').textContent = mins < 1 ? t('s4.now') : t('s4.ago', { m: mins });
      ol.appendChild(li);
      f.isNew = false;
    });
  }
  function tickHire() {
    hiredCount += Math.random() < 0.8 ? 1 : 2;
    renderCounter(true);
    var h = randomHire(0); h.isNew = true;
    feed.unshift(h); feed = feed.slice(0, 5);
    renderFeed();
    City.hire();
    setTimeout(tickHire, 3500 + Math.random() * 5500);
  }
  function startCounter() {
    seedCount(); seedFeed(); renderCounter(); renderFeed();
    if (CFG.hiredTodayUrl) {
      fetch(CFG.hiredTodayUrl).then(function (r) { return r.json(); }).then(function (j) {
        var n = j && j.data && j.data.count; if (typeof n === 'number') { hiredCount = n; renderCounter(); }
      }).catch(function () {});
    }
    setTimeout(tickHire, 2500);
    setInterval(renderFeed, 30000);
  }

  // ── First match ──────────────────────────────────────────────────────────
  var jobs = [], jobsLive = false;
  function seeded(str) { var h = 2166136261; for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function sampleJobs(tradeId) {
    var tr = tradeById(tradeId) || TRADES[0];
    var seed = seeded(place.c.pin + place.area + tradeId), r = function () { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
    var types = ['jt.full', 'jt.daily', 'jt.part'];
    return [0, 1, 2].map(function (i) {
      var pay = Math.round((tr.pay[0] + (tr.pay[1] - tr.pay[0]) * r()) / 10) * 10;
      return {
        title: tr[lang] || tr.en, tradeId: tr.id,
        employer: tr.employers[i % tr.employers.length],
        type: types[(i + Math.floor(r() * 3)) % 3],
        pay: pay,
        km: (0.6 + r() * 5.4).toFixed(1),
        match: i === 0 ? 90 + Math.floor(r() * 7) : 72 + Math.floor(r() * 16),
        replyHrs: 1 + Math.floor(r() * 5),
        verified: i !== 2 || r() > 0.5
      };
    });
  }
  function renderJobs() {
    var box = $('#jobs'); if (!box) return;
    if (!jobsLive) jobs = sampleJobs($('#trade').value || 'electrician');
    $('#resultsHead').textContent = t('s2.results', { area: place.area });
    $('#sampleNote').textContent = jobsLive ? t('s2.live') : t('s2.sample');
    box.innerHTML = '';
    jobs.forEach(function (j) {
      var el = document.createElement('article');
      el.className = 'job' + (j.match >= 90 ? ' top' : '');
      el.innerHTML =
        '<div class="job-top"><span class="match-pill"></span><span class="job-type"></span></div>' +
        '<h4 class="job-title"></h4>' +
        '<div class="job-emp"><span class="emp"></span></div>' +
        '<div class="job-pay"></div>' +
        '<div class="job-meta"><span class="dist"></span><span class="reply"></span></div>' +
        '<a class="btn btn-wa" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#wa-glyph"/></svg><span></span></a>';
      $('.match-pill', el).textContent = j.match + '% ' + t('s2.match');
      $('.job-type', el).textContent = t(j.type);
      $('.job-title', el).textContent = j.title;
      $('.emp', el).textContent = j.employer;
      if (j.verified) {
        var v = document.createElement('span'); v.className = 'verified';
        v.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 2 9.6 4.3 6.3 4l-.6 3.3L2.9 9.1 4.3 12l-1.4 2.9 2.8 1.8.6 3.3 3.3-.3L12 22l2.4-2.3 3.3.3.6-3.3 2.8-1.8L19.7 12l1.4-2.9-2.8-1.8-.6-3.3-3.3.3z"/><path d="m8.5 12.2 2.3 2.3 4.7-4.8" fill="none" stroke="#0C0A0E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
        v.appendChild(document.createTextNode(t('s2.verified')));
        $('.job-emp', el).appendChild(v);
      }
      $('.job-pay', el).innerHTML = '₹' + new Intl.NumberFormat('en-IN').format(j.pay) + '<small></small>';
      $('.job-pay small', el).textContent = t('s2.perDay');
      $('.dist', el).textContent = t('s2.away', { d: j.km });
      $('.reply', el).textContent = t('s2.replies', { h: j.replyHrs });
      var a = $('a', el);
      a.href = wa(t('wa.apply', { job: j.title + ', ' + j.employer + ' (' + place.area + ', ' + place.c.city + ')' }));
      $('a span', el).textContent = t('s2.apply');
      box.appendChild(el);
    });
  }
  function runMatch() {
    var tradeId = $('#trade').value;
    jobsLive = false;
    if (CFG.apiBase) {
      var url = CFG.apiBase.replace(/\/$/, '') + '/jobs/preview?lat=' + place.c.lat + '&lng=' + place.c.lng + '&limit=3&trade=' + encodeURIComponent(tradeId);
      fetch(url).then(function (r) { return r.json(); }).then(function (j) {
        var list = (j && j.data && (j.data.jobs || j.data.items || j.data)) || [];
        if (!Array.isArray(list) || !list.length) throw new Error('empty');
        jobs = list.slice(0, 3).map(function (x, i) {
          var sal = x.salary || {};
          return {
            title: x.title || tradeLabel(tradeId), tradeId: tradeId,
            employer: (x.employer && (x.employer.businessName || x.employer.name)) || x.employerName || x.company || 'Doondo employer',
            type: x.jobType === 'part_time' ? 'jt.part' : x.jobType === 'gig' || x.jobType === 'daily' ? 'jt.daily' : 'jt.full',
            pay: sal.max || sal.min || x.pay || x.wage || 0,
            km: x.distance ? (x.distance / 1000).toFixed(1) : '—',
            match: Math.round(x.matchScore || x.score || (92 - i * 7)),
            replyHrs: x.employerReplyHours || 2,
            verified: !!(x.employer && x.employer.verified) || !!x.verified
          };
        });
        jobsLive = true; renderJobs();
      }).catch(function () { renderJobs(); });
    }
    renderJobs();
  }
  $('#matchForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var pin = $('#pin').value.trim();
    if (!/^\d{6}$/.test(pin)) { toast(t('s2.badPin')); $('#pin').focus(); return; }
    var c = cityForPin(pin) || CITIES[0];
    var changed = c !== place.c;
    place = { c: c, area: c.areas[parseInt(pin.slice(3), 10) % c.areas.length] };
    if (changed) { seedFeed(); renderFeed(); }
    renderCounter(); updateHour(true);
    runMatch();
  });
  $('#trade').addEventListener('change', function () { runMatch(); });
  $('#locateBtn').addEventListener('click', function () {
    if (!navigator.geolocation) { toast(t('s2.noLoc')); return; }
    navigator.geolocation.getCurrentPosition(function (pos) {
      var best = CITIES[0], bd = 1e9;
      CITIES.forEach(function (c) {
        var d = Math.pow(c.lat - pos.coords.latitude, 2) + Math.pow(c.lng - pos.coords.longitude, 2);
        if (d < bd) { bd = d; best = c; }
      });
      $('#pin').value = best.pin;
      $('#matchForm').requestSubmit ? $('#matchForm').requestSubmit() : $('#matchForm').dispatchEvent(new Event('submit'));
    }, function () { toast(t('s2.noLoc')); }, { timeout: 8000, maximumAge: 600000 });
  });

  // ── Bolo: voice + typed search in the top bar ────────────────────────────
  function parseQuery(q) {
    var low = q.toLowerCase(), found = null, area = null, city = null;
    TRADES.forEach(function (tr) {
      if (found) return;
      if (tr.words.some(function (w) { return low.indexOf(w.toLowerCase()) !== -1; }) || low.indexOf((tr[lang] || '').toLowerCase()) !== -1) found = tr.id;
    });
    CITIES.forEach(function (c) {
      if (area) return;
      c.areas.forEach(function (a) { if (!area && low.indexOf(a.toLowerCase().replace('.', '')) !== -1) { area = a; city = c; } });
      if (!area && low.indexOf(c.city.toLowerCase()) !== -1) { city = c; }
    });
    var pinM = q.match(/\b\d{6}\b/);
    return { trade: found, area: area, city: city, pin: pinM && pinM[0] };
  }
  function handleQuery(q) {
    if (!q || !q.trim()) return;
    var p = parseQuery(q);
    if (p.pin) { $('#pin').value = p.pin; var c = cityForPin(p.pin) || CITIES[0]; place = { c: c, area: c.areas[0] }; }
    else if (p.city) { $('#pin').value = p.city.pin; place = { c: p.city, area: p.area || p.city.areas[0] }; }
    if (p.trade) $('#trade').value = p.trade;
    else toast(t('voice.notFound'), 4200);
    seedFeed(); renderFeed(); renderCounter(); updateHour(true);
    runMatch();
    $('#match').scrollIntoView({ behavior: isLite() ? 'auto' : 'smooth', block: 'start' });
  }
  $('#bolo').addEventListener('submit', function (e) { e.preventDefault(); handleQuery($('#boloInput').value); $('#boloInput').blur(); });

  var SR = window.SpeechRecognition || window.webkitSpeechRecognition, rec = null, listening = false;
  $('#micBtn').addEventListener('click', function () {
    if (!SR) { toast(t('voice.unsupported'), 4200); $('#boloInput').focus(); return; }
    if (listening && rec) { rec.stop(); return; }
    rec = new SR();
    rec.lang = LANGS[lang].speech; rec.interimResults = true; rec.maxAlternatives = 1;
    var finalText = '';
    rec.onstart = function () { listening = true; $('#micBtn').classList.add('listening'); toast(t('voice.listening'), 6000); };
    rec.onresult = function (ev) {
      var txt = '';
      for (var i = ev.resultIndex; i < ev.results.length; i++) { txt += ev.results[i][0].transcript; if (ev.results[i].isFinal) finalText = txt; }
      $('#boloInput').value = txt;
    };
    rec.onerror = function () { toast(t('voice.unsupported'), 4200); };
    rec.onend = function () {
      listening = false; $('#micBtn').classList.remove('listening');
      var q = finalText || $('#boloInput').value;
      if (q) { toast(t('voice.heard', { q: q })); handleQuery(q); }
    };
    try { rec.start(); } catch (e) { toast(t('voice.unsupported')); }
  });

  // ── Language menu ────────────────────────────────────────────────────────
  var langBtn = $('#langBtn'), langMenu = $('#langMenu');
  function closeMenu() { langMenu.hidden = true; langBtn.setAttribute('aria-expanded', 'false'); }
  langBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    var open = langMenu.hidden; langMenu.hidden = !open; langBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    if (open) $('button[aria-current="true"]', langMenu).focus();
  });
  langMenu.addEventListener('click', function (e) {
    var b = e.target.closest('button[data-lang]'); if (!b) return;
    applyLang(b.dataset.lang); closeMenu(); langBtn.focus();
  });
  document.addEventListener('click', function (e) { if (!e.target.closest('.lang')) closeMenu(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeMenu(); });

  $('#liteBtn').addEventListener('click', function () {
    var on = !isLite(); store.set('doondo.lite', on ? '1' : '0'); setLite(on, true);
  });

  // ── Payday stars ─────────────────────────────────────────────────────────
  var starsEl = $('#stars');
  for (var si = 1; si <= 5; si++) {
    var sb = document.createElement('button'); sb.type = 'button'; sb.dataset.v = si; sb.setAttribute('aria-label', si + ' / 5');
    sb.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 2.8 2.8 5.9 6.4.7-4.8 4.4 1.3 6.3L12 17l-5.7 3.1 1.3-6.3-4.8-4.4 6.4-.7z"/></svg>';
    starsEl.appendChild(sb);
  }
  var rated = 0;
  starsEl.addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    rated = +b.dataset.v;
    $$('button', starsEl).forEach(function (x) { x.classList.toggle('on', +x.dataset.v <= rated); });
    toast(t('s5.thanks'));
  });
  function renderStarsLabel() { /* label is data-i18n driven */ }

  // ── Skill Passport ───────────────────────────────────────────────────────
  var PP_LANGS = ['English', 'हिन्दी', 'தமிழ்', 'తెలుగు', 'ಕನ್ನಡ', 'मराठी', 'বাংলা', 'ગુજરાતી', 'മലയാളം', 'ଓଡ଼ିଆ'];
  var ppLangs = { 'English': true, 'हिन्दी': true, 'ಕನ್ನಡ': true };
  var chipBox = $('#ppLangs');
  PP_LANGS.forEach(function (l) {
    var b = document.createElement('button'); b.type = 'button'; b.textContent = l;
    b.setAttribute('aria-pressed', ppLangs[l] ? 'true' : 'false');
    b.addEventListener('click', function () {
      ppLangs[l] = !ppLangs[l]; b.setAttribute('aria-pressed', ppLangs[l] ? 'true' : 'false'); renderPassport(true);
    });
    chipBox.appendChild(b);
  });
  var wasGold = false, lastStamps = '';
  function ppData() {
    var name = $('#ppName').value.trim() || 'Your name';
    var years = +$('#ppYears').value;
    var langs = PP_LANGS.filter(function (l) { return ppLangs[l]; });
    var hasId = $('#ppId').checked;
    var score = Math.min(97, Math.round(55 + Math.min(years, 15) * 2 + Math.min(langs.length, 4) * 3 + (hasId ? 10 : 0)));
    var initials = name.split(/\s+/).filter(Boolean).slice(0, 2).map(function (p) { return p[0].toUpperCase(); }).join('') || 'D';
    var no = 'DN-' + place.c.pin + '-' + ('000' + (seeded(name) % 10000)).slice(-4);
    return { name: name, trade: $('#ppTrade').value, years: years, langs: langs, hasId: hasId, score: score, initials: initials,
      city: $('#ppCity').value.trim() || place.area + ', ' + place.c.city, no: no };
  }
  function renderPassport(animate) {
    var d = ppData(), card = $('#passportCard');
    $('#ppYearsOut').textContent = d.years;
    $('#ppInitials').textContent = d.initials;
    $('#ppNameOut').textContent = d.name;
    $('#ppTradeOut').textContent = tradeLabel(d.trade) + ' · ' + d.years + ' ' + t('pp.yrs');
    $('#ppCityOut').textContent = d.city;
    $('#ppScore').textContent = d.score;
    $('#ppRing').style.strokeDashoffset = (169.6 * (1 - d.score / 100)).toFixed(1);
    $('#ppNo').textContent = d.no;
    var lo = $('#ppLangsOut'); lo.innerHTML = '';
    d.langs.forEach(function (l) { var s = document.createElement('span'); s.textContent = l; lo.appendChild(s); });

    var gold = d.score >= 90;
    card.classList.toggle('gold', gold);
    $('#topSeal').hidden = !gold;
    if (gold && !wasGold && animate) { card.classList.remove('shine'); void card.offsetWidth; card.classList.add('shine'); }
    wasGold = gold;

    var stamps = [
      { k: 'pp.verified', on: d.hasId, cls: '', rot: -8 },
      { k: 'pp.safe', on: false, cls: '', rot: 6 },
      { k: 'pp.paid', on: d.years >= 1, cls: 'amber', rot: -4 },
      { k: 'pp.growing', on: d.years >= 3, cls: 'coral', rot: 9 }
    ];
    var sig = stamps.map(function (s) { return s.on ? 1 : 0; }).join('') + lang;
    if (sig !== lastStamps) {
      lastStamps = sig;
      var box = $('#stamps'); box.innerHTML = '';
      stamps.forEach(function (s) {
        var el = document.createElement('div');
        el.className = 'stamp ' + (s.on ? 'on ' + s.cls : 'off');
        el.style.setProperty('--rot', s.rot + 'deg');
        el.textContent = t(s.k);
        if (!s.on && s.k === 'pp.safe') { el.appendChild(document.createElement('br')); el.appendChild(document.createTextNode(t('pp.locked'))); }
        box.appendChild(el);
      });
    }
    $('#ppShare').href = wa(t('wa.share', { name: d.name, trade: tradeLabel(d.trade), years: d.years, score: d.score, city: d.city, url: CFG.siteUrl || location.href }), false);
  }
  ['#ppName', '#ppYears', '#ppCity', '#ppTrade', '#ppId'].forEach(function (s) {
    $(s).addEventListener('input', function () { renderPassport(true); });
    $(s).addEventListener('change', function () { renderPassport(true); });
  });

  // Gentle 3D tilt on the passport (full mode, fine pointers only)
  var card = $('#passportCard');
  if (window.matchMedia('(pointer: fine)').matches) {
    card.addEventListener('pointermove', function (e) {
      if (isLite()) return;
      var r = card.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
      card.style.transform = 'rotateY(' + (x * 10).toFixed(2) + 'deg) rotateX(' + (-y * 8).toFixed(2) + 'deg)';
    });
    card.addEventListener('pointerleave', function () { card.style.transform = ''; });
  }

  // Save passport as a PNG drawn on canvas (1080×1350, WhatsApp-friendly)
  $('#ppSave').addEventListener('click', function () {
    var d = ppData(), W = 1080, H = 1350, cv = document.createElement('canvas'); cv.width = W; cv.height = H;
    var c = cv.getContext('2d'), gold = d.score >= 90;
    var body = getComputedStyle(document.body).fontFamily, mono = '"JetBrains Mono", ui-monospace, monospace';
    var bg = c.createLinearGradient(0, 0, W, H); bg.addColorStop(0, '#1A1916'); bg.addColorStop(0.6, '#131216'); bg.addColorStop(1, '#0E0D11');
    c.fillStyle = bg; c.fillRect(0, 0, W, H);
    var glow = c.createRadialGradient(W, 0, 0, W, 0, 900); glow.addColorStop(0, 'rgba(200,83,58,0.22)'); glow.addColorStop(1, 'rgba(200,83,58,0)');
    c.fillStyle = glow; c.fillRect(0, 0, W, H);
    c.strokeStyle = 'rgba(236,232,223,0.035)'; c.lineWidth = 2;
    for (var r = 40; r < 1500; r += 30) { c.beginPath(); c.arc(W * 1.1, H * 1.2, r, 0, 6.283); c.stroke(); }
    c.strokeStyle = gold ? 'rgba(184,153,104,0.6)' : 'rgba(236,232,223,0.18)'; c.lineWidth = 3;
    rr(c, 30, 30, W - 60, H - 60, 56); c.stroke();
    // header
    pin(c, 110, 140, 1.7);
    c.fillStyle = '#ECE8DF'; c.font = '600 54px "Inter Tight", Inter, sans-serif'; c.textBaseline = 'middle'; c.fillText('doondo', 140, 132);
    c.fillStyle = '#9C988F'; c.font = '600 28px ' + body; c.textAlign = 'right'; c.fillText(t('pp.passport'), W - 100, 132); c.textAlign = 'left';
    // avatar
    c.fillStyle = '#C8533A'; rr(c, 100, 250, 200, 200, 44); c.fill();
    c.fillStyle = '#fff'; c.font = '600 84px "Inter Tight", Inter, sans-serif'; c.textAlign = 'center'; c.fillText(d.initials, 200, 352); c.textAlign = 'left';
    // name block
    c.fillStyle = '#ECE8DF'; c.font = '600 64px ' + body; c.fillText(fit(c, d.name, 520), 340, 300);
    c.fillStyle = 'rgba(236,232,223,0.85)'; c.font = '500 38px ' + body; c.fillText(fit(c, tradeLabel(d.trade) + ' · ' + d.years + ' ' + t('pp.yrs'), 520), 340, 370);
    c.fillStyle = '#9C988F'; c.font = '400 32px ' + body; c.fillText(fit(c, d.city, 520), 340, 425);
    // score ring
    var cx = 540, cy = 640, R = 130;
    c.lineWidth = 24; c.strokeStyle = 'rgba(236,232,223,0.08)'; c.beginPath(); c.arc(cx, cy, R, 0, 6.283); c.stroke();
    c.strokeStyle = gold ? '#B89968' : '#62BC9A'; c.lineCap = 'round';
    c.beginPath(); c.arc(cx, cy, R, -Math.PI / 2, -Math.PI / 2 + 6.283 * d.score / 100); c.stroke(); c.lineCap = 'butt';
    c.fillStyle = '#ECE8DF'; c.font = '500 96px ' + mono; c.textAlign = 'center'; c.fillText(String(d.score), cx, cy + 4);
    c.fillStyle = '#9C988F'; c.font = '500 32px ' + body; c.fillText(t('pp.score'), cx, cy + R + 60);
    // languages
    c.font = '500 30px ' + body; var lx = 540, line = d.langs.join('  ·  ');
    c.fillStyle = '#9C988F'; c.fillText(fit(c, line, 880), lx, 900);
    // stamps
    var st = [[t('pp.verified'), d.hasId, '#62BC9A'], [t('pp.safe'), false, '#6E6A63'], [t('pp.paid'), d.years >= 1, '#E0A744'], [t('pp.growing'), d.years >= 3, '#E18465']];
    st.forEach(function (s, i) {
      var x = 210 + i * 220, y = 1060, rot = [-0.14, 0.1, -0.07, 0.16][i];
      c.save(); c.translate(x, y); c.rotate(rot);
      c.strokeStyle = s[1] ? s[2] : '#6E6A63'; c.lineWidth = s[1] ? 6 : 3; if (!s[1]) c.setLineDash([10, 8]);
      c.beginPath(); c.arc(0, 0, 86, 0, 6.283); c.stroke(); c.setLineDash([]);
      c.fillStyle = s[1] ? s[2] : '#6E6A63'; c.font = '700 26px ' + body; c.fillText(fit(c, s[0], 150), 0, 0);
      c.restore();
    });
    // footer
    c.setLineDash([10, 10]); c.strokeStyle = 'rgba(236,232,223,0.18)'; c.lineWidth = 2;
    c.beginPath(); c.moveTo(100, 1200); c.lineTo(W - 100, 1200); c.stroke(); c.setLineDash([]);
    c.textAlign = 'left'; c.fillStyle = '#6E6A63'; c.font = '500 28px ' + mono; c.fillText(d.no, 100, 1250);
    if (gold) {
      c.textAlign = 'right'; c.fillStyle = '#B89968'; c.font = '600 30px ' + body; c.fillText(t('pp.top'), W - 100, 1250);
    }
    cv.toBlob(function (blob) {
      if (!blob) return;
      var a = document.createElement('a'); a.href = URL.createObjectURL(blob);
      a.download = 'doondo-skill-passport.png'; document.body.appendChild(a); a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
      toast(t('pp.saved'));
    }, 'image/png');
  });
  function rr(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  function pin(c, x, y, k) {
    c.save(); c.translate(x - 12 * k * 1.5, y - 22 * k * 1.5); c.scale(k * 1.5, k * 1.5);
    c.fillStyle = '#C8533A'; c.fill(new Path2D('M12 2a7 7 0 0 0-7 7c0 5.2 7 13 7 13s7-7.8 7-13a7 7 0 0 0-7-7z'));
    c.fillStyle = '#1A1916'; c.beginPath(); c.arc(12, 9, 2.6, 0, 6.283); c.fill(); c.restore();
  }
  function fit(c, s, max) { if (c.measureText(s).width <= max) return s; while (s.length > 1 && c.measureText(s + '…').width > max) s = s.slice(0, -1); return s + '…'; }

  // ── Boot ─────────────────────────────────────────────────────────────────
  function detectLang() {
    var saved = store.get('doondo.lang'); if (saved && STR[saved]) return saved;
    var list = navigator.languages || [navigator.language || 'en'];
    for (var i = 0; i < list.length; i++) { var code = (list[i] || '').slice(0, 2); if (STR[code]) return code; }
    return 'en';
  }
  City.init($('#city'));
  $('#trade').dataset.v = 'electrician'; $('#ppTrade').dataset.v = 'electrician';
  startCounter();
  applyLang(detectLang());
  measure();
  setLite(isLite(), false);
  if (root.dataset.liteAuto === '1') setTimeout(function () { toast(t('nav.liteAuto'), 5200); }, 900);
  window.addEventListener('load', function () { measure(); updateHour(true); });
})();
