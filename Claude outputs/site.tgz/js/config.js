/**
 * Doondo website settings. Edit these before going live.
 */
window.DOONDO_CONFIG = {
  // WhatsApp Business number, country code first, digits only (no +, no spaces).
  // TODO: replace with the real Doondo WhatsApp number.
  whatsappNumber: '919000000000',

  // Doondo API base URL, e.g. 'https://doondo-api.fly.dev/api'.
  // When set, "Drop your pin" calls GET {apiBase}/jobs/preview?lat&lng&trade&limit=3
  // (the public 60-second-first-match endpoint). Leave empty to show sample jobs.
  apiBase: '',

  // Optional endpoint returning { ok, data: { count } } for "hired near you today".
  // Leave empty to use the simulated counter.
  hiredTodayUrl: '',

  // App store links for "Get the app".
  playStoreUrl: 'https://play.google.com/store/apps/details?id=com.doondo.app',
  appStoreUrl: '',

  // Public URL of this site, used in the WhatsApp share text.
  siteUrl: 'https://doondo.in'
};
