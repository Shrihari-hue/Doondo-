/* The Doondo city: a layered 2.5D street that lives through one day.
   Scroll sets the hour; shutters open at dawn, windows light at night,
   coral pins drop when jobs are posted and jade rings burst on each hire. */
(function () {
  'use strict';

  var lerp = function (a, b, t) { return a + (b - a) * t; };
  var clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };
  var smooth = function (e0, e1, x) { var t = clamp((x - e0) / (e1 - e0), 0, 1); return t * t * (3 - 2 * t); };
  function hex(h) { var n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function mix(a, b, t) { return [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)]; }
  function rgba(c, a) { return 'rgba(' + (c[0] | 0) + ',' + (c[1] | 0) + ',' + (c[2] | 0) + ',' + (a == null ? 1 : a) + ')'; }
  function rng(seed) {
    return function () {
      seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
      var t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  // Sky keyframes: [hour, top, middle, horizon]. Kept dusky so the warm-black brand holds all day.
  var SKY = [
    [4, '#060509', '#0E0B14', '#1A1210'],
    [5.2, '#07060B', '#16101C', '#2E1813'],
    [6.3, '#141020', '#47212A', '#C8533A'],
    [7.6, '#262634', '#7A4C48', '#E0A744'],
    [10, '#2F3442', '#62625F', '#C9A57E'],
    [14, '#2C3240', '#5E5E5C', '#C49F78'],
    [17.4, '#221C2A', '#6E3326', '#E18465'],
    [18.8, '#140F1B', '#40192A', '#AD4129'],
    [20, '#09080D', '#15101A', '#3F140A'],
    [23, '#060509', '#0E0B14', '#1A1210']
  ].map(function (k) { return [k[0], hex(k[1]), hex(k[2]), hex(k[3])]; });

  function skyAt(h) {
    for (var i = 0; i < SKY.length - 1; i++) {
      var a = SKY[i], b = SKY[i + 1];
      if (h >= a[0] && h <= b[0]) {
        var t = smooth(a[0], b[0], h);
        return [mix(a[1], b[1], t), mix(a[2], b[2], t), mix(a[3], b[3], t)];
      }
    }
    var l = h < SKY[0][0] ? SKY[0] : SKY[SKY.length - 1];
    return [l[1], l[2], l[3]];
  }

  var SIGNS = ['CHAI', 'TAILOR', 'KIRANA', 'MOBILES', 'SALON', 'HARDWARE', 'MEDICAL', 'BAKERY', 'XEROX', 'TIFFIN', 'FLOWERS', 'ELECTRICALS', 'SWEETS', 'TYRES'];
  var SIGN_COLS = ['#8C311C', '#074434', '#6D4709', '#3A2E4A', '#672213', '#0A5A45'];
  var FACADES = ['#231C20', '#1E191D', '#2A2125', '#201A17', '#262022'];
  var CORAL = hex('#C8533A'), JADE = hex('#62BC9A'), AMBER = hex('#E0A744'), WIN = hex('#E0A744');

  var City = {
    cv: null, ctx: null, W: 0, H: 0, dpr: 1, s: 1,
    hour: 5, targetHour: 5, scrollFrac: 0,
    mx: 0, my: 0, tmx: 0, tmy: 0,
    layers: null, pins: [], rings: [], cars: [], stars: [],
    running: false, last: 0, spawnT: 0, carT: 0, time: 0,

    init: function (canvas) {
      this.cv = canvas;
      this.ctx = canvas.getContext('2d');
      var self = this;
      this.resize();
      window.addEventListener('resize', function () { self.resize(); });
      window.addEventListener('pointermove', function (e) {
        self.tmx = (e.clientX / window.innerWidth) * 2 - 1;
        self.tmy = (e.clientY / window.innerHeight) * 2 - 1;
      }, { passive: true });
      document.addEventListener('visibilitychange', function () {
        if (document.hidden) self.stop(); else if (self.wanted) self.start();
      });
    },

    resize: function () {
      var dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      this.dpr = dpr;
      this.W = window.innerWidth; this.H = window.innerHeight;
      this.cv.width = Math.round(this.W * dpr); this.cv.height = Math.round(this.H * dpr);
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      this.s = clamp(Math.min(this.W / 1200, this.H / 800), 0.62, 1.25);
      this.build();
      this.draw();
    },

    build: function () {
      var W = this.W, H = this.H, s = this.s, r = rng(20261022);
      this.ground = H * (W < 640 ? 0.80 : 0.82);
      var margin = 60;
      var layers = [];
      // far, mid, near-shops
      var specs = [
        { depth: 0.18, minW: 50, maxW: 110, minH: 0.20, maxH: 0.46, win: false },
        { depth: 0.45, minW: 46, maxW: 96, minH: 0.14, maxH: 0.34, win: true },
        { depth: 1.0, minW: 64, maxW: 104, minH: 0.085, maxH: 0.12, shop: true }
      ];
      for (var li = 0; li < specs.length; li++) {
        var sp = specs[li], items = [], x = -margin;
        while (x < W + margin) {
          var w = lerp(sp.minW, sp.maxW, r()) * s;
          var h = lerp(sp.minH, sp.maxH, r()) * H;
          var b = { x: x, w: w, h: h, seed: Math.floor(r() * 1e9) };
          if (sp.win) {
            b.cols = Math.max(2, Math.floor(w / (14 * s)));
            b.rows = Math.max(3, Math.floor(h / (18 * s)));
            b.wins = [];
            for (var k = 0; k < b.cols * b.rows; k++) b.wins.push(r());
            b.tank = r() < 0.35; // rooftop water tank, every Indian skyline has them
          }
          if (sp.shop) {
            b.sign = SIGNS[Math.floor(r() * SIGNS.length)];
            b.signCol = SIGN_COLS[Math.floor(r() * SIGN_COLS.length)];
            b.facade = FACADES[Math.floor(r() * FACADES.length)];
            b.openAt = 6.6 + r() * 2.2;
            b.closeAt = 20.2 + r() * 1.6;
            b.upper = r() < 0.6; // a floor above the shop
            b.upperH = lerp(0.05, 0.09, r()) * H;
            b.upperWins = [r(), r(), r()];
          }
          items.push(b);
          x += w + (sp.shop ? 2 * s : lerp(2, 14, r()) * s);
        }
        layers.push({ spec: sp, items: items });
      }
      this.layers = layers;
      this.stars = [];
      for (var i = 0; i < 90; i++) this.stars.push({ x: r() * W, y: r() * H * 0.55, r: r() * 1.2 + 0.3, tw: r() * 6.28 });
    },

    setHour: function (h, scrollFrac) { this.targetHour = h; if (scrollFrac != null) this.scrollFrac = scrollFrac; if (!this.running) { this.hour = h; this.draw(); } },

    activity: function (h) { return 0.15 + 0.85 * smooth(5.4, 9, h) * (1 - smooth(19, 22, h)); },
    night: function (h) { return clamp(1 - smooth(5.6, 7.6, h) + smooth(17.8, 20, h), 0, 1); },

    pickRoof: function () {
      var L = this.layers[Math.random() < 0.55 ? 2 : 1];
      var off = this.offsetX(L.spec.depth);
      for (var tries = 0; tries < 12; tries++) {
        var b = L.items[Math.floor(Math.random() * L.items.length)];
        var cx = b.x + b.w / 2 + off;
        if (cx > 30 && cx < this.W - 30) {
          var top = L.spec.shop ? this.ground - b.h - (b.upper ? b.upperH : 0) : this.ground - b.h;
          return { x: cx, y: top, depth: L.spec.depth };
        }
      }
      return { x: Math.random() * this.W, y: this.ground - 80, depth: 1 };
    },

    spawnPin: function () {
      var p = this.pickRoof();
      var pay = Math.random() < 0.4 ? '₹' + (Math.round((520 + Math.random() * 480) / 10) * 10) : null;
      this.pins.push({ x: p.x, y: p.y, t: 0, life: 5 + Math.random() * 3, pay: pay, sc: lerp(0.75, 1.05, p.depth) });
      if (this.pins.length > 28) this.pins.shift();
    },

    hire: function () {
      if (!this.running) return;
      var p;
      if (this.pins.length && Math.random() < 0.8) {
        var pin = this.pins.splice(Math.floor(Math.random() * this.pins.length), 1)[0];
        p = { x: pin.x, y: pin.y - 18 * pin.sc };
      } else { var rf = this.pickRoof(); p = { x: rf.x, y: rf.y - 10 }; }
      this.rings.push({ x: p.x, y: p.y, t: 0 });
    },

    offsetX: function (depth) { return -this.mx * depth * 26; },
    offsetY: function (depth) { return this.scrollFrac * depth * 24 + this.my * depth * 6; },

    start: function () {
      this.wanted = true;
      if (this.running || document.hidden) return;
      this.running = true; this.last = performance.now();
      var self = this;
      var loop = function (now) {
        if (!self.running) return;
        var dt = Math.min(0.1, (now - self.last) / 1000);
        if (dt >= 1 / 32) { self.last = now; self.tick(dt); self.draw(); }
        self.raf = requestAnimationFrame(loop);
      };
      this.raf = requestAnimationFrame(loop);
    },
    stop: function () { this.running = false; if (this.raf) cancelAnimationFrame(this.raf); },
    pause: function () { this.wanted = false; this.stop(); },

    tick: function (dt) {
      this.time += dt;
      this.hour = lerp(this.hour, this.targetHour, 1 - Math.pow(0.02, dt));
      this.mx = lerp(this.mx, this.tmx, 1 - Math.pow(0.05, dt));
      this.my = lerp(this.my, this.tmy, 1 - Math.pow(0.05, dt));
      var act = this.activity(this.hour);
      this.spawnT -= dt;
      if (this.spawnT <= 0) { this.spawnPin(); this.spawnT = (0.9 + Math.random() * 1.2) / (act * 1.4); }
      for (var i = this.pins.length - 1; i >= 0; i--) { this.pins[i].t += dt; if (this.pins[i].t > this.pins[i].life) this.pins.splice(i, 1); }
      for (var j = this.rings.length - 1; j >= 0; j--) { this.rings[j].t += dt; if (this.rings[j].t > 1.6) this.rings.splice(j, 1); }
      this.carT -= dt;
      if (this.carT <= 0) {
        var dir = Math.random() < 0.5 ? 1 : -1;
        var kind = Math.random() < 0.5 ? 'auto' : (Math.random() < 0.6 ? 'scooter' : 'bus');
        this.cars.push({ x: dir > 0 ? -80 : this.W + 80, dir: dir, kind: kind, v: (kind === 'bus' ? 55 : kind === 'auto' ? 80 : 105) * this.s, lane: dir > 0 ? 1 : 0 });
        this.carT = (1.2 + Math.random() * 2.4) / act;
      }
      for (var c = this.cars.length - 1; c >= 0; c--) {
        var car = this.cars[c]; car.x += car.dir * car.v * dt;
        if (car.x < -120 || car.x > this.W + 120) this.cars.splice(c, 1);
      }
    },

    draw: function () {
      if (!this.ctx || !this.layers) return;
      var ctx = this.ctx, W = this.W, H = this.H, s = this.s, h = this.hour;
      var sky = skyAt(h), night = this.night(h), G = this.ground;

      // Sky
      var g = ctx.createLinearGradient(0, 0, 0, G);
      g.addColorStop(0, rgba(sky[0])); g.addColorStop(0.55, rgba(sky[1])); g.addColorStop(1, rgba(sky[2]));
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);

      // Stars
      if (night > 0.05) {
        for (var i = 0; i < this.stars.length; i++) {
          var st = this.stars[i];
          var a = night * (0.35 + 0.35 * Math.sin(this.time * 1.3 + st.tw));
          ctx.fillStyle = 'rgba(236,232,223,' + a.toFixed(3) + ')';
          ctx.fillRect(st.x - this.mx * 4, st.y, st.r, st.r);
        }
      }

      // Sun and moon on one arc
      var sunT = (h - 6) / 12.5, sx = lerp(W * 0.12, W * 0.9, sunT), sy = G - Math.sin(clamp(sunT, 0, 1) * Math.PI) * G * 0.72 + 10;
      if (sunT > -0.08 && sunT < 1.08) {
        var sunCol = mix(hex('#E18465'), hex('#F2D9A6'), Math.sin(clamp(sunT, 0, 1) * Math.PI));
        var halo = ctx.createRadialGradient(sx, sy, 0, sx, sy, 120 * s);
        halo.addColorStop(0, rgba(sunCol, 0.55)); halo.addColorStop(1, rgba(sunCol, 0));
        ctx.fillStyle = halo; ctx.beginPath(); ctx.arc(sx, sy, 120 * s, 0, 6.283); ctx.fill();
        ctx.fillStyle = rgba(sunCol, 0.95); ctx.beginPath(); ctx.arc(sx, sy, 22 * s, 0, 6.283); ctx.fill();
      }
      if (night > 0.3) {
        var mx = W * 0.78 - this.mx * 6, my = H * 0.16;
        ctx.fillStyle = 'rgba(236,232,223,' + (0.85 * night).toFixed(3) + ')';
        ctx.beginPath(); ctx.arc(mx, my, 16 * s, 0, 6.283); ctx.fill();
        ctx.fillStyle = rgba(sky[0], 1);
        ctx.beginPath(); ctx.arc(mx + 7 * s, my - 4 * s, 14 * s, 0, 6.283); ctx.fill();
      }

      // Far skyline
      var far = this.layers[0], fo = this.offsetX(far.spec.depth), fy = this.offsetY(far.spec.depth);
      ctx.fillStyle = rgba(mix(sky[1], hex('#0C0A0E'), 0.55), 1);
      for (var f = 0; f < far.items.length; f++) {
        var fb = far.items[f];
        ctx.fillRect(fb.x + fo, G - fb.h + fy, fb.w, fb.h + 40);
      }
      // haze
      var hz = ctx.createLinearGradient(0, G - H * 0.3, 0, G);
      hz.addColorStop(0, rgba(sky[2], 0)); hz.addColorStop(1, rgba(sky[2], 0.22 + 0.1 * (1 - night)));
      ctx.fillStyle = hz; ctx.fillRect(0, G - H * 0.3, W, H * 0.3);

      // Mid buildings with windows and rooftop tanks
      var mid = this.layers[1], mo = this.offsetX(mid.spec.depth), myo = this.offsetY(mid.spec.depth);
      var midCol = mix(sky[1], hex('#0C0A0E'), 0.72);
      var litP = 0.08 + 0.6 * night;
      for (var m = 0; m < mid.items.length; m++) {
        var b = mid.items[m], bx = b.x + mo, by = G - b.h + myo;
        if (bx > W + 10 || bx + b.w < -10) continue;
        ctx.fillStyle = rgba(midCol, 1); ctx.fillRect(bx, by, b.w, b.h + 40);
        if (b.tank) { ctx.fillRect(bx + b.w * 0.6, by - 9 * s, 12 * s, 9 * s); }
        var cw = b.w / b.cols, rh = b.h / b.rows;
        for (var rI = 0; rI < b.rows - 1; rI++) for (var cI = 0; cI < b.cols; cI++) {
          var v = b.wins[rI * b.cols + cI];
          var lit = v < litP;
          ctx.fillStyle = lit ? rgba(WIN, 0.55 + 0.35 * night) : 'rgba(236,232,223,' + (0.03 + 0.04 * (1 - night)).toFixed(3) + ')';
          ctx.fillRect(bx + cI * cw + cw * 0.3, by + rI * rh + rh * 0.45, cw * 0.42, rh * 0.38);
        }
      }

      // Near row: shops with roll-up shutters and signboards
      var near = this.layers[2], no = this.offsetX(1), ny = this.offsetY(1);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '700 ' + Math.round(8.5 * s) + 'px Inter, system-ui, sans-serif';
      for (var n = 0; n < near.items.length; n++) {
        var sh = near.items[n], x0 = sh.x + no, top = G - sh.h + ny;
        if (x0 > W + 10 || x0 + sh.w < -10) continue;
        if (sh.upper) {
          ctx.fillStyle = sh.facade; ctx.fillRect(x0, top - sh.upperH, sh.w, sh.upperH);
          for (var u = 0; u < 3; u++) {
            var ulit = sh.upperWins[u] < litP + 0.1;
            ctx.fillStyle = ulit ? rgba(WIN, 0.7) : 'rgba(236,232,223,0.05)';
            ctx.fillRect(x0 + sh.w * (0.12 + u * 0.29), top - sh.upperH * 0.72, sh.w * 0.18, sh.upperH * 0.42);
          }
        }
        ctx.fillStyle = sh.facade; ctx.fillRect(x0, top, sh.w, sh.h + 60);
        // signboard
        var sgH = 13 * s;
        ctx.fillStyle = sh.signCol; ctx.fillRect(x0 + 3 * s, top + 3 * s, sh.w - 6 * s, sgH);
        ctx.fillStyle = 'rgba(236,232,223,0.85)';
        ctx.fillText(sh.sign, x0 + sh.w / 2, top + 3 * s + sgH / 2 + 0.5);
        // doorway
        var dx = x0 + 5 * s, dy = top + sgH + 7 * s, dw = sh.w - 10 * s, dh = G + ny - dy;
        var open = smooth(sh.openAt, sh.openAt + 0.8, h) * (1 - smooth(sh.closeAt, sh.closeAt + 0.6, h));
        var inside = ctx.createLinearGradient(0, dy, 0, dy + dh);
        inside.addColorStop(0, rgba(AMBER, 0.55 + 0.25 * night)); inside.addColorStop(1, rgba(hex('#8C311C'), 0.6));
        ctx.fillStyle = inside; ctx.fillRect(dx, dy, dw, dh);
        if (open > 0.4) { // a shopkeeper silhouette
          ctx.fillStyle = 'rgba(12,10,14,0.75)';
          var px = dx + dw * (0.3 + ((sh.seed % 40) / 100));
          ctx.beginPath(); ctx.arc(px, dy + dh * 0.42, 4 * s, 0, 6.283); ctx.fill();
          ctx.fillRect(px - 5 * s, dy + dh * 0.42 + 4 * s, 10 * s, dh * 0.5);
        }
        var shut = dh * (1 - open);
        if (shut > 0.5) {
          ctx.fillStyle = '#3A3530'; ctx.fillRect(dx, dy, dw, shut);
          ctx.fillStyle = 'rgba(12,10,14,0.45)';
          for (var y = dy + 3 * s; y < dy + shut; y += 3.2 * s) ctx.fillRect(dx, y, dw, 1);
        }
        // light spill onto the pavement at night
        if (open > 0.1 && night > 0.2) {
          ctx.fillStyle = rgba(AMBER, 0.08 * night * open);
          ctx.beginPath(); ctx.moveTo(dx, G + ny); ctx.lineTo(dx + dw, G + ny); ctx.lineTo(dx + dw + 14 * s, G + ny + 18 * s); ctx.lineTo(dx - 14 * s, G + ny + 18 * s); ctx.fill();
        }
      }

      // Street
      var gy = G + ny;
      ctx.fillStyle = '#1C1A1F'; ctx.fillRect(0, gy, W, 7 * s);
      var road = ctx.createLinearGradient(0, gy + 7 * s, 0, H);
      road.addColorStop(0, '#141217'); road.addColorStop(1, '#0C0A0E');
      ctx.fillStyle = road; ctx.fillRect(0, gy + 7 * s, W, H - gy);
      var laneY = gy + 7 * s + (H - gy - 7 * s) * 0.45;
      ctx.fillStyle = 'rgba(236,232,223,0.10)';
      for (var lx = (-this.mx * 20) % 60 - 60; lx < W + 60; lx += 60) ctx.fillRect(lx, laneY, 28, 2);

      // Traffic
      for (var c2 = 0; c2 < this.cars.length; c2++) this.drawVehicle(this.cars[c2], gy, laneY, night);

      // Job pins
      for (var p = 0; p < this.pins.length; p++) this.drawPin(this.pins[p]);
      // Hire rings
      for (var q = 0; q < this.rings.length; q++) {
        var rg = this.rings[q], t = rg.t / 1.6;
        ctx.strokeStyle = rgba(JADE, (1 - t) * 0.9); ctx.lineWidth = 2.5 * s;
        ctx.beginPath(); ctx.arc(rg.x, rg.y, (8 + 46 * t) * s, 0, 6.283); ctx.stroke();
        if (t < 0.7) {
          ctx.fillStyle = rgba(JADE, 1 - t / 0.7);
          ctx.beginPath(); ctx.arc(rg.x, rg.y, 9 * s, 0, 6.283); ctx.fill();
          ctx.strokeStyle = 'rgba(12,10,14,' + (1 - t / 0.7).toFixed(2) + ')'; ctx.lineWidth = 2 * s;
          ctx.beginPath(); ctx.moveTo(rg.x - 4 * s, rg.y); ctx.lineTo(rg.x - 1 * s, rg.y + 3 * s); ctx.lineTo(rg.x + 4.5 * s, rg.y - 3 * s); ctx.stroke();
        }
      }
    },

    drawPin: function (p) {
      var ctx = this.ctx, s = this.s * p.sc;
      var drop = Math.min(1, p.t / 0.55);
      var bounce = drop < 1 ? (1 - Math.pow(1 - drop, 3)) : 1;
      var fade = p.t > p.life - 0.6 ? (p.life - p.t) / 0.6 : 1;
      var y = p.y - 6 * s - (1 - bounce) * 60 * s;
      ctx.globalAlpha = clamp(fade, 0, 1);
      // shadow
      ctx.fillStyle = 'rgba(0,0,0,0.35)';
      ctx.beginPath(); ctx.ellipse(p.x, p.y - 1, 5 * s * bounce, 1.8 * s, 0, 0, 6.283); ctx.fill();
      // teardrop
      ctx.fillStyle = rgba(CORAL, 1);
      ctx.beginPath();
      ctx.arc(p.x, y - 14 * s, 8 * s, Math.PI * 0.85, Math.PI * 0.15);
      ctx.lineTo(p.x, y); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#0C0A0E'; ctx.beginPath(); ctx.arc(p.x, y - 14 * s, 3 * s, 0, 6.283); ctx.fill();
      if (p.pay && p.t > 0.5) {
        var a = Math.min(1, (p.t - 0.5) / 0.4);
        ctx.globalAlpha = clamp(fade * a, 0, 1);
        ctx.font = '500 ' + Math.round(11 * s) + 'px "JetBrains Mono", ui-monospace, monospace';
        var tw = ctx.measureText(p.pay).width + 12 * s;
        var bx = p.x - tw / 2, by = y - 40 * s;
        ctx.fillStyle = 'rgba(19,18,22,0.92)';
        this.round(bx, by, tw, 17 * s, 8.5 * s); ctx.fill();
        ctx.fillStyle = rgba(AMBER, 1); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(p.pay, p.x, by + 9 * s);
      }
      ctx.globalAlpha = 1;
    },

    drawVehicle: function (c, gy, laneY, night) {
      var ctx = this.ctx, s = this.s, y = c.lane ? laneY + 22 * s : laneY - 4 * s, x = c.x;
      var dir = c.dir;
      if (c.kind === 'auto') { // three-wheeler: green-yellow body, black canopy
        ctx.fillStyle = '#C9A227'; this.round(x - 17 * s, y - 16 * s, 34 * s, 12 * s, 4 * s); ctx.fill();
        ctx.fillStyle = '#0E6E54'; this.round(x - 15 * s, y - 25 * s, 28 * s, 10 * s, 5 * s); ctx.fill();
        ctx.fillStyle = '#0C0A0E';
        ctx.beginPath(); ctx.arc(x - 11 * s, y - 3 * s, 3.5 * s, 0, 6.283); ctx.arc(x + 12 * s * dir, y - 3 * s, 3.5 * s, 0, 6.283); ctx.fill();
      } else if (c.kind === 'scooter') {
        ctx.fillStyle = '#C8533A'; this.round(x - 10 * s, y - 12 * s, 20 * s, 7 * s, 3 * s); ctx.fill();
        ctx.fillStyle = '#272622'; ctx.beginPath(); ctx.arc(x - 2 * s * dir, y - 19 * s, 4 * s, 0, 6.283); ctx.fill();
        ctx.fillRect(x - 4 * s, y - 16 * s, 6 * s, 6 * s);
        ctx.fillStyle = '#0C0A0E';
        ctx.beginPath(); ctx.arc(x - 8 * s, y - 3 * s, 3 * s, 0, 6.283); ctx.arc(x + 8 * s, y - 3 * s, 3 * s, 0, 6.283); ctx.fill();
      } else {
        ctx.fillStyle = '#3D3A34'; this.round(x - 40 * s, y - 30 * s, 80 * s, 26 * s, 5 * s); ctx.fill();
        ctx.fillStyle = night > 0.3 ? 'rgba(224,167,68,0.7)' : 'rgba(236,232,223,0.15)';
        for (var i = 0; i < 6; i++) ctx.fillRect(x - 34 * s + i * 11.5 * s, y - 26 * s, 8 * s, 8 * s);
        ctx.fillStyle = '#0C0A0E';
        ctx.beginPath(); ctx.arc(x - 26 * s, y - 3 * s, 4.5 * s, 0, 6.283); ctx.arc(x + 26 * s, y - 3 * s, 4.5 * s, 0, 6.283); ctx.fill();
      }
      if (night > 0.3) { // headlight beam
        var hx = x + dir * (c.kind === 'bus' ? 40 : 17) * s;
        var beam = ctx.createLinearGradient(hx, 0, hx + dir * 60 * s, 0);
        beam.addColorStop(0, 'rgba(242,217,166,' + (0.35 * night).toFixed(2) + ')'); beam.addColorStop(1, 'rgba(242,217,166,0)');
        ctx.fillStyle = beam;
        ctx.beginPath(); ctx.moveTo(hx, y - 12 * s); ctx.lineTo(hx + dir * 60 * s, y - 20 * s); ctx.lineTo(hx + dir * 60 * s, y); ctx.closePath(); ctx.fill();
      }
    },

    round: function (x, y, w, h, r) {
      var ctx = this.ctx; ctx.beginPath();
      ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
    }
  };

  City.skyAt = skyAt;
  window.DoondoCity = City;
})();
