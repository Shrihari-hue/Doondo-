# Doondo Website V3

"The City Wakes Up": the site is one day in an Indian city. Scrolling moves the clock from 5 AM to 9 PM.
Shutters open, windows light up, coral pins drop when jobs are posted and jade rings burst on every hire.

Plain HTML, CSS and JavaScript. No build step. Host the folder anywhere (Netlify, Vercel, Cloudflare Pages, S3, or Fly).

## Run it locally

    cd "Doondo Website V3"
    python3 -m http.server 8080
    # open http://localhost:8080

Open it through a local server rather than double-clicking index.html, so the voice and location features work.

## What's on the page

| Time | Section | What it does |
|---|---|---|
| 05:00 | Hero | Headline, Skill Passport + WhatsApp buttons, live "hired near you today" counter |
| 06:00 | Morning digest | Example of the daily push notification |
| 09:00 | First match | Pincode + trade shows 3 jobs (calls `/jobs/preview` when `apiBase` is set) |
| 11:00 | Safe at work | Selfie check-in, SOS + Trust Circle, Women Mode |
| 14:00 | Hired near you | Live feed of hires, synced with the counter and the jade rings in the city |
| 19:00 | Payday | Wallet credit + rate the employer |
| 21:00 | Skill Passport | Main call to action: build a card, share on WhatsApp, save as a 1080×1350 image |
| 21:30 | Employers | "Hire on WhatsApp" |

Always on screen: the top bar with the mic search ("driver in Andheri" works by voice or typing), the language switch
(English, हिन्दी, தமிழ், తెలుగు, ಕನ್ನಡ) and the Lite toggle, plus the floating WhatsApp button.

## Lite mode

Lite turns off the animated city and the glass blur and shows a static skyline whose sky colour still follows the time of day.
It switches on automatically for Data Saver, 2G/3G connections, phones with 2 GB of memory or less, 2-core CPUs,
and people who ask their phone to reduce motion. Anyone can flip it with the Lite button; the choice is remembered.
In full mode the canvas caps at 30 fps, 1.5× pixel density, and pauses when the tab is hidden.

## Before going live: edit `js/config.js`

- `whatsappNumber`: the real Doondo WhatsApp Business number (placeholder now).
- `apiBase`: e.g. `https://doondo-api.fly.dev/api`. Then "Drop your pin" shows real jobs from `GET /jobs/preview`.
  The backend must allow CORS from the website's domain.
- `hiredTodayUrl`: optional endpoint returning `{ ok, data: { count } }`. Until then the counter is simulated
  (seeded by time of day, ticking every few seconds), so don't call it real numbers in marketing.
- `playStoreUrl` / `siteUrl`: check these match the published app and domain.

## Brand

Colours come from `packages/tokens` in Doondo V2: brick coral is the hero, jade means trust/match/verified,
amber means money, and champagne gold appears only for a 90+ top match and the Top-10% passport seal.
WhatsApp green is used only on WhatsApp buttons. Fonts: Inter / Inter Tight / JetBrains Mono, with Noto Sans
for Hindi, Tamil, Telugu and Kannada (loaded only when that language is picked).

## Still to do

- Native-speaker check of the Tamil, Telugu and Kannada copy in `js/i18n.js`.
- Real WhatsApp number, API connection and hired-today endpoint (see above).
- Voice search uses the browser's speech recognition: Chrome on Android and desktop support it; Firefox and some iOS browsers don't (the site falls back to typing).
